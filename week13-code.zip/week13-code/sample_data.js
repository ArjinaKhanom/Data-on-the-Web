// USE SAMPLE_TRAINING
// 1 COMPARISON OPERATORS

// find all trips less than 70 seconds long
db.trips.find({ "tripduration": { "$lte": 70 } }).pretty()

// find al trips less than 70 seconds long and that werent taken by a NON-subscriber to citybike
db.trips.find({
    "tripduration": { "$lte": 70 },
    "usertype": { "$ne": "Subscriber" }
}).pretty()


// because userTypes are only 'Customer' or 'Subscriber' setting the EQUALS to customer returns the set that doesn't have 'Subscribers'
db.trips.find({
    "tripduration": { "$lte": 70 },
    "usertype": { "$eq": "Customer" }
}).pretty()

// Below is the same query, when an comparison operator is omitted, the EQUALS comparison is used as default
db.trips.find({
    "tripduration": { "$lte": 70 },
    "usertype": "Customer"
}).pretty()





// 2 LOGIC OPERATORS

//$and is present by default: below query is same as query above it

db.trips.find({
    "$and": [
        { "tripduration": { "$lte": 70 } },
        { "usertype": "Customer" }
    ]
}).pretty()

//OR returns documents which match at least one query
db.trips.find({
    "$or": [
        { "tripduration": { "$lte": 70 } },
        { "usertype": "Customer" }
    ]
}).pretty()


//NOR returns documents which do not match at ALL the quries
db.trips.find({
    "$nor": [
        { "tripduration": { "$lte": 70 } },
        { "usertype": "Customer" }
    ]
}).pretty()








//EXPRESSIVE QUERIES AND INTRO TO AGGREGATION SYNTAX
// flexible, similar use as nested queries in SQL
db.trips.find({
    "$expr": { "$eq": ["$end station id", "$start station id"] }
}).pretty()

// add 'count()' to verify the number - without it you will get a iterable of records - traverse with 'IT'

//combining operators 
db.trips.find({
    "$expr": {
        "$and": [{ "$ne": ["$usertype", 'Subscriber'] },
            { "$eq": ["$end station id", "$start station id"] }
        ]
    }
}).count()

// -NOTE- THIS DIFFERS FROM COMPARISON OPERATOR SYNTAX:

// {<field>: {<operator>:<value>} 

// \/example below\/


// db.trips.find({
//     "tripduration": { "$lte": 70 },
//     "usertype": { "$eq": "Customer" }
// }).pretty()

// WITH AGGREGATION SYNTAX THE OPERATOR GOES FIRST (IN THIS CASE: '$ne' and '$eq'):
// {<operator>:<field> {:<value>}
// Connecr to Mongo Shell with updated syntax (old way will still work)
mongo "mongodb+srv://<USERNAME>:<PASSWORD>@resume.jsxrr.mongodb.net/<dbname>"



// DUMP NATIVE BSON (BINARY JSON)
mongodump--uri "mongodb+srv://<USERNAME>:<PASSWORD>@resume.jsxrr.mongodb.net/<dbname>"

// for me
mongodump--uri "mongodb+srv://admin:admin@resume.jsxrr.mongodb.net/resume"



//EXPORT JSON (human readable)
mongoexport--uri "mongodb+srv://<USERNAME>:<PASSWORD>@resume.jsxrr.mongodb.net/<dbname>"--collection = YOUR_COLLECTION_NAME--out = out.json;

//for me
mongoexport--uri "mongodb+srv://admin:admin@resume.jsxrr.mongodb.net/resume"--collection = resume--out = out.json;




// RESTORE FROM BINARY FILE
mongorestore "mongodb+srv://<USERNAME>:<PASSWORD>@resume.jsxrr.mongodb.net/<dbname>"--drop

//for me
mongorestore--uri "mongodb+srv://admin:admin@resume.jsxrr.mongodb.net/resume"--drop